INSERT INTO products SET idType = 5, name = "THIOPENTAL sodique, 500 mg, poudre, fl.", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 175, unit = "Flacon - 50", timestamp = 1704187969;
INSERT INTO products SET idType = 5, name = "PenCURONIUM bromure, 10 mg, poudre, fl.", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 40, unit = "Flacon - 10", timestamp = 1704187969;
INSERT INTO products SET idType = 5, name = "SUXAMETHONIUM chlorure,  50 mg/ml, 2 ml, amp.", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 25, unit = "ampoule - 10", timestamp = 1704187969;
INSERT INTO products SET idType = 5, name = "FENTANYL citrate, éq. 0,05mg/ml base, 2ml, amp.", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 23, unit = "ampoule - 10", timestamp = 1704187969;
INSERT INTO products SET idType = 5, name = "PROPOFOL, 10mg/ml, 20ml, émulsion, amp.", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 19.5, unit = "ampoule - 5", timestamp = 1704187969;
INSERT INTO products SET idType = 5, name = "Bupivacaine 0.5% (20 mL) flacon(Isobare)", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 85, unit = "Flacon - 20", timestamp = 1704187969;
INSERT INTO products SET idType = 5, name = "Ketamine, 50mg/ml, 10ml, Vial", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 55, unit = "1 Vial - 25", timestamp = 1704187969;
INSERT INTO products SET idType = 5, name = "Lidocaïne chlorhydrate, 2%, 20 ml, Vial, Unité", nameOfType =  "Produits d'Anesthesie", inStock = 0, price = 12, unit = "1amp - 20", timestamp = 1704187969;
