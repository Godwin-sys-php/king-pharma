INSERT INTO products SET idType = 9, name = "Congélateur Vestfrost  MF 314", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 0, unit = "piece - 1", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "Réfrigérateur vestfrost MK 204 OU 304", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 0, unit = "piece - 1", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "RCW25(Cool BOX)", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 0, unit = "piece - 1", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "Porte Vaccin(6L)", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 95, unit = "piece - 4", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "Accumulateurs de Froid (Icepacks) 0.6L", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 4, unit = "piece - 243", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "Logtag électronniqueavec écran pour lecture (tableau lecture)", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 0, unit = "Pce - 10", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "Carte 3M ", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 0, unit = "Pce - 150", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "Freezetag ", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 0, unit = "Pce - 1", timestamp = 1704187969;
INSERT INTO products SET idType = 9, name = "Lecteur Logtag", nameOfType =  "Chaine de Froid Projet", inStock = 0, price = 0, unit = "Pce - 1", timestamp = 1704187969;
